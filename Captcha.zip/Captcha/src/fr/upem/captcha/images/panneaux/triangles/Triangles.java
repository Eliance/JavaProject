package fr.upem.captcha.images.panneaux.triangles;

import java.io.File;
import java.util.ArrayList;

import fr.upem.captcha.images.Capchable;
import fr.upem.captcha.images.panneaux.Panneaux;

//M�me principe que pour la classe Panneaux : cf. architecture des fichiers
public class Triangles extends Panneaux  implements Capchable{
	
	public Triangles() {}
	
	@Override
	public ArrayList<String> getPhotos() {
		ArrayList<String> photos =  new ArrayList<String>();
		
		StringBuilder pathBuilder = new StringBuilder();
		pathBuilder.append("src").append(File.separator).append("fr").append(File.separator).append("upem").append(File.separator).append("captcha").append(File.separator).append("images").append(File.separator).append("panneaux").append(File.separator).append("triangles");
		
		File folder = new File(pathBuilder.toString());
		
		String[] files = folder.list();
		for(String path : files){
			if (path.endsWith("jpeg")==true || path.endsWith("png")==true || path.endsWith("jpg")==true) {
				photos.add(pathBuilder.toString()+File.separator+path);
			}	
		}
		return photos;
	}


	@Override
	public String toString() {
		String str = new String(" triangles"); 
		return super.toString()+str;
	}
}
